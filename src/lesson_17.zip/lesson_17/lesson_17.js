import './lesson_17.scss';
import {List} from './scrypts/list';
import {Form} from './scrypts/form';

new Form();
new List();